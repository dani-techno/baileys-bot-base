import makeWASocket, { Browsers, useMultiFileAuthState, fetchLatestBaileysVersion, DisconnectReason, makeCacheableSignalKeyStore } from '@whiskeysockets/baileys'
import pino from 'pino'
import readline from 'readline'
import fs from 'fs'
import QRCode from 'qrcode'
import qrcodeTerminal from 'qrcode-terminal'
import path from 'path'

// === SETTING MODE DISINI ===
// 'pairing' | 'qr-terminal' | 'qr-image'
const MODE = 'pairing'
const AUTH_FOLDER = 'auth_info'
const QR_PATH = './qr.png'
const QR_REFRESH_INTERVAL = 120_000

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

let qrInterval = null
let pairingInterval = null
let lastQR = null
let currentPhoneNumber = null
let isWaitingAuth = false

// === WARNA BUAT LOGGER ===
const C = {
    reset: '\x1b[0m',
    dim: '\x1b[2m',
    green: '\x1b[32m',
    cyan: '\x1b[36m',
    yellow: '\x1b[33m',
    magenta: '\x1b[35m',
    blue: '\x1b[34m',
    red: '\x1b[31m',
    bgGreen: '\x1b[42m\x1b[30m',
    bgBlue: '\x1b[44m\x1b[37m',
}

function formatPairingCode(code) {
    if (!code) return code
    const raw = code.replace(/-/g, '').trim().toUpperCase()
    if (raw.length <= 3) return raw
    const mid = Math.floor(raw.length / 2)
    return `${raw.slice(0, mid)}-${raw.slice(mid)}`
}

function cleanCredsIfInvalid() {
    const credsPath = `${AUTH_FOLDER}/creds.json`
    if (!fs.existsSync(credsPath)) return
    try {
        const data = JSON.parse(fs.readFileSync(credsPath, 'utf-8'))
        if (!data.registered) {
            if (isWaitingAuth) {
                console.log('ℹ️ creds.json belum registered tapi lagi nunggu auth, dibiarin dulu...')
                return
            }
            console.log('⚠️ creds.json belum terhubung sebelum scan/pairing, lagi hapus biar gak error...')
            fs.rmSync(credsPath, { force: true })
            if (fs.existsSync(QR_PATH)) {
                fs.rmSync(QR_PATH, { force: true })
                console.log('🗑️ qr.png ikut dihapus karena creds belum konek')
            }
        }
    } catch {
        console.log('⚠️ creds.json corrupt, lagi hapus...')
        fs.rmSync(credsPath, { force: true })
        if (fs.existsSync(QR_PATH)) fs.rmSync(QR_PATH, { force: true })
    }
}

function clearAllIntervals() {
    if (qrInterval) { clearInterval(qrInterval); qrInterval = null }
    if (pairingInterval) { clearInterval(pairingInterval); pairingInterval = null }
}

async function displayQRImageOnly(qr) {
    try {
        const absPath = path.resolve(QR_PATH)
        await QRCode.toFile(QR_PATH, qr, { width: 512, margin: 1 })
        console.log(`\n[${new Date().toLocaleTimeString()}] [QR-IMAGE]`)
        console.log(`✅ QR disimpan di ${absPath}, buka file itu di panel Ptero buat scan!\n`)
    } catch (e) {
        console.log('❌ Gagal generate QR png:', e.message)
    }
}

function displayQRTerminalOnly(qr) {
    console.log(`\n[${new Date().toLocaleTimeString()}] [QR-TERMINAL] Scan QR di bawah:`)
    qrcodeTerminal.generate(qr, { small: true })
    console.log(`\nQR akan refresh otomatis tiap 2 menit\n`)
}

function formatNumber(input) {
    let num = input.replace(/[^0-9]/g, '')
    if (!num) return null
    if (num.startsWith('0')) num = '62' + num.slice(1)
    else if (num.startsWith('8')) num = '62' + num
    if (num.startsWith('0') || num.length < 10) return null
    return num
}

async function getValidPhoneNumber() {
    if (currentPhoneNumber && isWaitingAuth) return currentPhoneNumber
    while (true) {
        let input = await question('Masukin nomor WA lu (62xxxx): ')
        if (!input.trim()) { console.log('❌ Nomor gak boleh kosong!'); continue }
        const formatted = formatNumber(input)
        if (!formatted) { console.log('❌ Format salah! Contoh: 628123456789 atau 08123456789'); continue }
        return formatted
    }
}

// Helper ambil text dari content sendMessage biar bisa di log
function extractOutgoingText(content) {
    if (!content) return '-'
    if (content.text) return content.text
    if (content.caption) return content.caption
    if (content.conversation) return content.conversation
    return JSON.stringify(content).slice(0, 200)
}

async function startBot() {
    clearAllIntervals()
    cleanCredsIfInvalid()

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        },
        logger: pino({ level: 'silent' }),
        browser: Browsers.macOS("Safari"),
        printQRInTerminal: false,
        markOnlineOnConnect: false,
        syncFullHistory: false,
        fireInitQueries: false,
        generateHighQualityLinkPreview: false,
        version,
    })

    sock.ev.on('creds.update', saveCreds)

    // === WRAPPER SENDMESSAGE BIAR AUTO LOG OUTGOING ===
    const originalSendMessage = sock.sendMessage.bind(sock)
    sock.sendMessage = async (jid, content, options = {}) => {
        const result = await originalSendMessage(jid, content, options)
        try {
            const isGroup = jid.endsWith('@g.us')
            const text = extractOutgoingText(content)
            const time = new Date().toLocaleTimeString()
            const target = jid.split('@')[0]

            let groupName = '-'
            if (isGroup) {
                try {
                    const meta = await sock.groupMetadata(jid)
                    groupName = meta.subject
                } catch { groupName = 'Grup' }
            }

            console.log(`${C.green}┌─${C.reset} ${C.bgGreen} BOT REPLY ${C.reset} ${C.dim}[${time}]${C.reset}`)
            console.log(`${C.green}│${C.reset} ${C.cyan}➜ Ke :${C.reset} ${target} ${isGroup? `${C.yellow}(${groupName})${C.reset}` : ''}`)
            console.log(`${C.green}│${C.reset} ${C.cyan}➜ JID :${C.reset} ${C.dim}${jid}${C.reset}`)
            console.log(`${C.green}│${C.reset} ${C.cyan}➜ Tipe :${C.reset} ${isGroup? 'GRUP' : 'PRIVATE'}`)
            console.log(`${C.green}└─${C.reset} ${C.cyan}➜ Balasan :${C.reset} ${C.green}${text}${C.reset}\n`)
        } catch (e) {
            // jangan ganggu flow kalau log gagal
        }
        return result
    }

    if (MODE === 'pairing' &&!state.creds.registered) {
        await new Promise(r => setTimeout(r, 2000))
        currentPhoneNumber = await getValidPhoneNumber()
        if (fs.existsSync(QR_PATH)) fs.rmSync(QR_PATH, { force: true })

        const requestAndShowCode = async (isRefresh = false) => {
            try {
                isWaitingAuth = true
                const rawCode = await sock.requestPairingCode(currentPhoneNumber)
                const code = formatPairingCode(rawCode)
                const tag = isRefresh? 'PAIRING REFRESH (2m)' : 'PAIRING CODE'
                console.log(`\n[${new Date().toLocaleTimeString()}] [${tag}]`)
                console.log(`Kode pairing lu: ${code}`)
                console.log(`Nomor: ${currentPhoneNumber}`)
                console.log(`Buka WA > Perangkat Tertaut > Tautkan dengan nomor telepon\n`)
            } catch (err) {
                console.log(`❌ Gagal pairing percobaan: ${err.message}`)
            }
        }
        await requestAndShowCode(false)
        pairingInterval = setInterval(() => requestAndShowCode(true), QR_REFRESH_INTERVAL)
    }

    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
        if (qr) { lastQR = qr; isWaitingAuth = true }

        if (qr && MODE === 'pairing') {
        } else if (qr && MODE === 'qr-terminal') {
            displayQRTerminalOnly(qr)
            if (qrInterval) clearInterval(qrInterval)
            qrInterval = setInterval(() => {
                if (!lastQR) return
                console.log(`\n[${new Date().toLocaleTimeString()}] [QR-TERMINAL REFRESH 2m]`)
                qrcodeTerminal.generate(lastQR, { small: false })
            }, QR_REFRESH_INTERVAL)
        } else if (qr && MODE === 'qr-image') {
            await displayQRImageOnly(qr)
            if (qrInterval) clearInterval(qrInterval)
            qrInterval = setInterval(async () => {
                if (!lastQR) return
                await displayQRImageOnly(lastQR)
                console.log(`[${new Date().toLocaleTimeString()}] [QR-IMAGE REFRESH 2m] File ${QR_PATH} diperbarui`)
            }, QR_REFRESH_INTERVAL)
        }

        if (connection === 'open') {
            clearAllIntervals()
            lastQR = null
            isWaitingAuth = false
            console.log('✅ Bot konek bos!')
            if (fs.existsSync(QR_PATH)) fs.rmSync(QR_PATH, { force: true })
            try { rl.close() } catch {}
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode
            const errMsg = lastDisconnect?.error?.message || ''
            const isRestartRequired = statusCode === DisconnectReason.restartRequired || errMsg.includes('restart required') || errMsg.includes('Stream Errored')
            console.log('Koneksi ketutup...', errMsg)
            if (isRestartRequired && isWaitingAuth) {
                console.log(`[${new Date().toLocaleTimeString()}] Restart required pas nunggu pairing/qr, restart langsung...`)
                clearAllIntervals()
                setTimeout(startBot, 1000)
                return
            }
            clearAllIntervals()
            const isLoggedOut = statusCode === DisconnectReason.loggedOut
            if (isLoggedOut || statusCode === 401) {
                console.log('Logout, hapus auth...')
                isWaitingAuth = false
                currentPhoneNumber = null
                if (fs.existsSync(AUTH_FOLDER)) fs.rmSync(AUTH_FOLDER, { recursive: true, force: true })
                if (fs.existsSync(QR_PATH)) fs.rmSync(QR_PATH, { force: true })
            } else if (!isWaitingAuth) { isWaitingAuth = false }
            if (!isWaitingAuth) currentPhoneNumber = null
            setTimeout(startBot, 2000)
        }
    })

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const m = messages[0]
        if (!m.message || m.key.fromMe) return

        const jid = m.key.remoteJid
        const text = (m.message.conversation || m.message.extendedTextMessage?.text || m.message.imageMessage?.caption || "").trim()
        if (!text.startsWith('.')) return

        const isGroup = jid.endsWith('@g.us')
        const senderJid = isGroup? (m.key.participant || m.participant || '') : jid
        const senderNumber = (senderJid || jid).split('@')[0].split(':')[0]
        const senderName = m.pushName || 'Tanpa Nama'
        const time = new Date().toLocaleTimeString()

        let groupName = '-'
        let groupId = '-'
        if (isGroup) {
            groupId = jid
            try {
                const meta = await sock.groupMetadata(jid)
                groupName = meta.subject || '-'
            } catch { groupName = '(gagal ambil nama grup)' }
        }

        // INCOMING LOG dengan warna
        console.log(`\n${C.blue}┌─${C.reset} ${C.bgBlue} INCOMING CMD ${C.reset} ${C.dim}[${time}]${C.reset} ${C.yellow}${text}${C.reset}`)
        console.log(`${C.blue}│${C.reset} ${C.cyan}├─ Pengirim :${C.reset} ${senderName} ${C.dim}|${C.reset} ${C.magenta}${senderNumber}${C.reset}`)
        console.log(`${C.blue}│${C.reset} ${C.cyan}├─ JID Pengirim :${C.reset} ${C.dim}${senderJid || jid}${C.reset}`)
        if (isGroup) {
            console.log(`${C.blue}│${C.reset} ${C.cyan}├─ Tipe :${C.reset} ${C.yellow}GRUP${C.reset}`)
            console.log(`${C.blue}│${C.reset} ${C.cyan}├─ Nama Grup :${C.reset} ${groupName}`)
            console.log(`${C.blue}│${C.reset} ${C.cyan}├─ ID Grup :${C.reset} ${C.dim}${groupId}${C.reset}`)
        } else {
            console.log(`${C.blue}│${C.reset} ${C.cyan}├─ Tipe :${C.reset} PRIVATE CHAT`)
            console.log(`${C.blue}│${C.reset} ${C.cyan}├─ Chat ID :${C.reset} ${C.dim}${jid}${C.reset}`)
        }
        console.log(`${C.blue}└─${C.reset} ${C.cyan}└─ Pesan :${C.reset} ${text}\n`)

        // CASES
        if (text === '.ping') {
            await sock.sendMessage(jid, { text: 'pong' }, { quoted: m })
        }
    })
}

startBot()